from django.forms import ModelForm
from teamsports.models import Teams, Schedule, Sports, School, Photo, GameNotes, User
from django import forms
from django.forms import widgets, HiddenInput
from django.shortcuts import get_object_or_404, HttpResponseRedirect, render, redirect

class SelectTeam(ModelForm):
    #team = forms.ModelChoiceField(queryset=Teams.objects.all(), widget=forms.HiddenInput())
    team_name = forms.ModelChoiceField(queryset=Teams.objects.all(), initial=0)

    def clean_data(self):
        data=self.cleaned_data['team']
        return data

    class Meta:
        model = Teams
        fields = ['team']

class SelectMatch(ModelForm):
    match = forms.ModelChoiceField(queryset=Schedule.objects.all().order_by('match_date'), initial=0)

    class Meta:
        model = Schedule
        fields = ['match']

class SelectSport(ModelForm):
    sport = forms.ModelChoiceField(queryset=Sports.objects.all(), initial=0)

    def clean_data(self):
        data=self.cleaned_data['sport']
        return data

    class Meta:
        model = Sports
        fields = ['sport']

class SelectSchool(ModelForm):
    school = forms.ModelChoiceField(queryset=School.objects.all(), initial=0)

    def clean_data(self):
        data=self.cleaned_data['school']
        return data

    class Meta:
        model = School
        fields = ['school']

class SelectUser(ModelForm):
    user = forms.ModelChoiceField(queryset=User.objects.all(), initial=0)

    def clean_data(self):
        data=self.cleaned_data['the_user']
        return data

    class Meta:
        model = School
        fields = ['user']

class AddPicture(ModelForm):
    picture = forms.ImageField()

    class Meta:
        model = Photo
        fields = ['photo', 'team_photo', 'game']

class UpdateScore(ModelForm):
    success_url = '/'
    class Meta:
        model = Schedule
        fields = ['home_score', 'away_score', 'is_disputed']
        is_disputed = forms.BooleanField(initial=False, required=False)

class Notes(ModelForm):

    class Meta:
        model = GameNotes
        fields = ['notes']

class ReportPhoto(forms.Form):
    SOME_CHOICES = [
        ('inappropirate', 'Inappropriate'),
        ('not relavent', 'Not relavent to the game'),
        ('mean-spirited','Mean-spirited'),
        ('racist', 'Racist/Sexist/Homophobic/In violation of The Pub ToS'),
        ('other','Other')
        ]

    reason = forms.MultipleChoiceField(choices=SOME_CHOICES)
    notes = forms.CharField(required=False)
    email = forms.EmailField(required=False)

class Contact(forms.Form):
    contact_name = forms.CharField(required=True)
    contact_email = forms.EmailField(required=True)
    content = forms.CharField(
        required=True,
        widget=forms.Textarea
    )

    # the new bit we're adding
    def __init__(self, *args, **kwargs):
        super(Contact, self).__init__(*args, **kwargs)
        self.fields['contact_name'].label = "Your name:"
        self.fields['contact_email'].label = "Your email:"
        self.fields['content'].label = "What do you want to say?"
